import jax
import jax.numpy as jnp
from jax import lax

from inference.MP_Inference import lds_inference_simple, lds_inference_and_sample_simple, hmm_inference
from inference.MP_Inference import hmm_to_lds_simple, lds_to_hmm_simple, lds_kl_simple, hmm_kl
from jax.random import dirichlet
from jax.experimental import host_callback
from utils import wandb_log_internal

# Forward optimization hyperparameters
MAX_ITER = 20
CONV_THRESH = 1e-6

# Backward optimization hyperparameters
RICHARDSON_CLIPPING_THRESH = 1e10
BWD_LR = 0.5

def initialize(initializer, recog_potentials, transition_potentials):
    if initializer.shape == (2,):
        N, K = recog_potentials[0].shape[0], transition_potentials[0].shape[0]
        cat_expected_stats = dirichlet(initializer, jnp.ones(K)*0.1, shape=(N,))
    else:
        cat_expected_stats = initializer
    return cat_expected_stats.astype(transition_potentials[0].dtype)

def sample_and_kl_simple(recog_potentials, init_potentials, transition_potentials, 
                         init_lps, trans_lps, cat_expected_stats, key, temp=1.):
    gaus_init, gaus_natparam, E_prior_logZ = hmm_to_lds_simple(cat_expected_stats, init_potentials, transition_potentials)
    gaus_expected_stats, gaus_logZ, z = lds_inference_and_sample_simple(recog_potentials, gaus_init, gaus_natparam, key, temp=temp)
    gaus_kl = lds_kl_simple(recog_potentials, gaus_expected_stats, E_prior_logZ, gaus_logZ)

    cat_natparam = lds_to_hmm_simple(gaus_expected_stats, init_potentials, transition_potentials)
    cat_expected_stats, hmm_logZ = hmm_inference(init_lps, trans_lps, cat_natparam)[:2]
    cat_kl = hmm_kl(cat_natparam, cat_expected_stats, hmm_logZ)
    return z, gaus_kl + cat_kl, gaus_expected_stats

# doesn't compute KL-divergence, which is not needed for the backward pass
def block_update(recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, cat_expected_stats):
    gaus_init, gaus_natparam = hmm_to_lds_simple(cat_expected_stats, init_potentials, transition_potentials)[:2]
    gaus_expected_stats = lds_inference_simple(recog_potentials, gaus_init, gaus_natparam)[0]

    cat_natparam = lds_to_hmm_simple(gaus_expected_stats, init_potentials, transition_potentials)
    cat_expected_stats = hmm_inference(init_lps, trans_lps, cat_natparam)[0]
    return cat_expected_stats

def slds_inference_simple(recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, initializer):
    cat_expected_stats = initialize(initializer, recog_potentials, transition_potentials)
    
    def update_fn(cat_expected_stats, _):
        cat_es = block_update(recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, cat_expected_stats)
        return cat_es, cat_es

    return lax.scan(update_fn, cat_expected_stats, xs=None, length=MAX_ITER)[0]

def slds_inference_simple_fwd(recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, initializer):
    cat_expected_stats = initialize(initializer, recog_potentials, transition_potentials)

    def update_fn(cat_expected_stats, _):
        cat_es = block_update(recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, cat_expected_stats)
        return cat_es, cat_es

    cat_expected_stats, trajectory = lax.scan(update_fn, cat_expected_stats, xs=None, length=MAX_ITER)
    
    # check convergence
    resid = jnp.mean(abs(trajectory[-1] - trajectory[-2]))
    converged = resid < CONV_THRESH

    # log
    log_fn = lambda arg, _: wandb_log_internal(dict(coordinate_ascent_tol=jnp.max(jnp.abs(arg[0])), nconverged=jnp.mean(arg[1])))
    host_callback.id_tap(log_fn, (resid, converged))

    # collect residuals for backpropagation
    all_args = recog_potentials, init_potentials, transition_potentials, init_lps, trans_lps, cat_expected_stats, converged
    return cat_expected_stats, all_args

def slds_inference_simple_bwd(resids, grads):
    with jax.default_matmul_precision('float32'):
        pu_args = resids[:-2]
        cat_expected_stats = resids[-2]
        converged = resids[-1]

        def block_update_local(cat_expected_stats):
            return block_update(*pu_args, cat_expected_stats)

        def block_update_global(*pu_args):
            return block_update(*pu_args, cat_expected_stats)

        square_vjp_fun = jax.vjp(block_update_local, cat_expected_stats)[1]

        def richardson_iter(g, _):
            return (1.-BWD_LR) * g + BWD_LR * square_vjp_fun(g)[0] + BWD_LR * grads, None

        full_grads = lax.scan(richardson_iter, grads, xs=None, length=MAX_ITER)[0]

        # Log richardson residuals
        output = square_vjp_fun(full_grads)[0]
        resid = grads + output - full_grads
        resid_rmse = jnp.sqrt(jnp.mean(resid ** 2))

        # provide no-solve solution for sequences that did not converge on the forward pass
        cond = jnp.bitwise_or((resid_rmse > RICHARDSON_CLIPPING_THRESH) | jnp.isnan(resid_rmse), ~converged)
        full_grads = jnp.where(cond, grads, full_grads)

        resid_rmse = jnp.where(cond, jnp.zeros_like(resid_rmse), resid_rmse)
        host_callback.id_tap(lambda c, _: wandb_log_internal(dict(richardson_unconv=jnp.mean(c))), cond)
        host_callback.id_tap(lambda resid, _: wandb_log_internal(dict(richardson_resid=jnp.max(resid))), resid_rmse)

        global_vjp_fun = jax.vjp(block_update_global, *pu_args)[1]
        return global_vjp_fun(full_grads) + (None,)

slds_inference_simple_implicit = jax.custom_vjp(slds_inference_simple)
slds_inference_simple_implicit.defvjp(slds_inference_simple_fwd, slds_inference_simple_bwd)
