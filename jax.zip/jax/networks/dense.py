import flax.linen as nn
from flax.linen import Module, Dense, BatchNorm, leaky_relu, softplus, compact
from jax.numpy import expand_dims, diag, zeros_like, ones_like
from jax import vmap
from typing import Callable, Optional, Any, Sequence
from distributions import normal
from functools import partial
import jax.numpy as jnp
from tensorflow_probability.substrates.jax import distributions as tfd
from .sequence import SimpleLSTM, SimpleBiLSTM, ReverseLSTM
from jax.image import resize
import jax
import numpy as np
import math
from networks.layers import LayerNorm

ModuleDef = Any

class DenseBlock(Module):
    n_features: int
    activation: Callable = leaky_relu
    norm_cls: Optional[ModuleDef] = None
    dtype: Any = jnp.float32
    eval_mode: bool = False

    @nn.compact
    def __call__(self, x):
        x = Dense(self.n_features, dtype=self.dtype)(x)
        if self.norm_cls:
            x = self.norm_cls(use_running_average=self.eval_mode, dtype=self.dtype)(x)
        x = self.activation(x)
        return x

class ResDenseSkipConnection(nn.Module):
    out_shape: Any
    dtype: Any = jnp.float32
    
    @nn.compact
    def __call__(self, x):
        if x.shape != self.out_shape:
            x = Dense(self.out_shape[-1], dtype=self.dtype)(x)
        return x

class DenseNet(nn.Module):
    n_outputs: int
    block_cls: ModuleDef = DenseBlock
    resnet: bool = False
    stage_sizes: Sequence[int] = (4,)
    hidden_sizes: Sequence[int] = (100,)
    dtype: Any = jnp.float32
    activation: Callable = leaky_relu
    norm_cls: Optional[ModuleDef] = LayerNorm
    eval_mode: bool = False
    lstm_layer: Any = -1
    lstm_cls: ModuleDef = ReverseLSTM
    lstm_hidden_size: int = 64
    scale_input: float = 1.
    scale_output: float = 1.

    @nn.compact
    def __call__(self, x, mask=None):
        x = x / self.scale_input
        stage_sizes, hidden_sizes = self.stage_sizes, self.hidden_sizes
        block_cls = partial(self.block_cls, eval_mode=self.eval_mode, dtype=self.dtype, activation=self.activation)
        
        lstm_layer = [self.lstm_layer] if type(self.lstm_layer) is int else self.lstm_layer

        layers = []
        for i, (hsize, n_blocks) in enumerate(zip(hidden_sizes, stage_sizes)):
            if self.lstm_cls and self.lstm_hidden_size > 0 and i in lstm_layer:
                x = self.lstm_cls(self.lstm_hidden_size)(x, mask=mask)
            
            x_res = x
            if n_blocks < 0: # indicating a layer which should factorize across angles
                x = x.reshape(x.shape[:-1] + (-1,-n_blocks))
                x = block_cls(n_features=hsize, norm_cls=self.norm_cls,)(x)
                x = x.reshape(x.shape[:-2] + (-1,))
            else:
                for b in range(n_blocks - 1):
                    x = block_cls(n_features=hsize, norm_cls=self.norm_cls,)(x)
                x = block_cls(n_features=hsize, norm_cls=self.norm_cls,)(x)
            
            if self.resnet and i > 0:
                x = x + x_res

        if self.lstm_cls and self.lstm_hidden_size > 0 and len(stage_sizes) == lstm_layer[-1]:
            x = self.lstm_cls(self.lstm_hidden_size)(x, mask=mask)

        if (len(stage_sizes) > len(hidden_sizes)) and stage_sizes[-1] < 0:
            x = x.reshape(x.shape[:-1] + (-1,-stage_sizes[-1])) # (128, 150, 20, 12)
            x = block_cls(n_features=self.n_outputs//x.shape[-2], dtype=self.dtype)(x) # (128, 150, 20, 6)
            x = x.reshape(x.shape[:-2] + (-1,))
        else:
            x = nn.Dense(self.n_outputs, dtype=self.dtype)(x)
        return x * self.scale_output
    
class MLPBlock(Module):
    n_features: int
    activation: Callable = leaky_relu
    dtype: Any = jnp.float32

    @nn.compact
    def __call__(self, x):
        x = Dense(self.n_features, dtype=self.dtype)(x)
        x = self.activation(x)
        x = Dense(self.n_features, dtype=self.dtype)(x)
        return x

class TransformerLayer(Module):
    n_features: int
    num_heads: int = 4
    activation: Callable = leaky_relu
    norm_cls: Optional[ModuleDef] = LayerNorm
    dropout_rate: float = 0.0
    dtype: Any = jnp.float32
    eval_mode: bool = False

    @nn.compact
    def __call__(self, x):
        x_res = x
        x = self.norm_cls(use_running_average=self.eval_mode, dtype=self.dtype)(x)
        x = nn.MultiHeadAttention(num_heads=self.num_heads, dropout_rate=self.dropout_rate,
                                  deterministic=self.eval_mode, dtype=self.dtype)(x)
        x = x + x_res
        
        x_res = x
        x = self.norm_cls(use_running_average=self.eval_mode, dtype=self.dtype)(x)
        x = MLPBlock(self.n_features, activation = self.activation, dtype=self.dtype)(x)
        return x + x_res

class PositionalEncoding(nn.Module):
    d_model : int        # Hidden dimensionality of the input.
    max_len : int = 1000  # Maximum length of a sequence to expect.

    def setup(self):
        # Create matrix of [SeqLen, HiddenDim] representing the positional encoding for max_len inputs
        pe = np.zeros((self.max_len, self.d_model))
        position = np.arange(0, self.max_len, dtype=np.float32)[:,None]
        div_term = np.exp(np.arange(0, self.d_model, 2) * (-math.log(10000.0) / self.d_model))
        pe[:, 0::2] = np.sin(position * div_term)
        pe[:, 1::2] = np.cos(position * div_term)
        pe = pe[None]
        self.pe = jax.device_put(pe)

    def __call__(self, x):
        x = x + self.pe[:, :x.shape[1]]
        return x

class Net(nn.Module):
    n_outputs: int
    block_cls: ModuleDef = TransformerLayer
    interp_method: str = 'bilinear'
    pool_method: Optional[Callable] = nn.avg_pool
    positional_encoding: bool = False
    scaling_sizes: Sequence[int] = (0,)
    hidden_sizes: Sequence[int] = (256,)
    dtype: Any = jnp.float32
    activation: Callable = leaky_relu
    norm_cls: Optional[ModuleDef] = LayerNorm
    eval_mode: bool = False

    @nn.compact
    def __call__(self, x, mask=None):
        block_cls = partial(self.block_cls, eval_mode=self.eval_mode, 
                            dtype=self.dtype, activation=self.activation, norm_cls = self.norm_cls)

        for i, (hsize, scaling_factor) in enumerate(zip(self.hidden_sizes, self.scaling_sizes)):
            if i == 0:
                x = MLPBlock(n_features=hsize, activation = self.activation, dtype=self.dtype)(x)
                if self.positional_encoding:
                    x = PositionalEncoding(d_model=hsize)(x)
            else:
                if scaling_factor > 1:
                    x = resize(x, x.shape[:-2] + (x.shape[-2] * scaling_factor, x.shape[-1]), 
                               method=self.interp_method)
                elif scaling_factor < -1:
                    x = self.pool_method(x, window_shape=(-scaling_factor,), strides=(-scaling_factor,))

                x = block_cls(n_features=hsize)(x)

        x = MLPBlock(n_features=self.n_outputs, activation = self.activation, dtype=self.dtype)(x)
        return x